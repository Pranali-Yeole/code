﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Test.Models;
using System.Web.Security;

namespace Test.Controllers
{
    public class AccountController : Controller
    {
        DBBlogreviewEntities dBBlogReviewEntities = new DBBlogreviewEntities();
        // GET: Account
        public ActionResult Login()
        {

            return View();


        }
        [HttpPost]
        public ActionResult Login(User user)
        {
            bool isValid = dBBlogReviewEntities.Users.Any(x => x.UserName == user.UserName && x.Password == user.Password);
            if (isValid)
            {
                FormsAuthentication.SetAuthCookie(user.UserName, false);
                return RedirectToAction("Index", "Admin");
            }

            ModelState.AddModelError("", "Invalid username and password");
            return View();
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

    }
}
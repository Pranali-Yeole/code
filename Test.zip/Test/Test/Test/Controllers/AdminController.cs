﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Test.Models;
namespace Test.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        DBBlogreviewEntities dBBlogReviewEntities = new DBBlogreviewEntities();
        // GET: Admin
        public ActionResult Index()
        {
            return View(dBBlogReviewEntities.Blogs.ToList());
        }

        [HttpGet]
        public ActionResult addBlog()
        {
            return View();
        }

        public ActionResult addBlog(Blog blog)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(HttpUtility.HtmlEncode(blog.Description));
            stringBuilder.Replace("&lt;b&gt;", "<b>");
            stringBuilder.Replace("&lt;/b&gt;", "</b>");
            stringBuilder.Replace("&lt;u&gt;", "<u>");
            stringBuilder.Replace("&lt;/u&gt;", "</u>");
            stringBuilder.Replace("&lt;i&gt;", "<i>");
            stringBuilder.Replace("&lt;/i&gt;", "</i>");
            blog.Description = stringBuilder.ToString();

            if (ModelState.IsValid)
            {
                dBBlogReviewEntities.Blogs.Add(blog);
                dBBlogReviewEntities.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(blog);

        }

        //Show All Comment with respect blogs
        public ActionResult ShowComment(int? id)
        {
            var list = dBBlogReviewEntities.Comments.Where((y => y.BlogId == id)).ToList();
            return View(list);
        }
        [HttpGet]
        public PartialViewResult UpdateComment(int id)
        {
            Comment comment = dBBlogReviewEntities.Comments.Where(x => x.ID == id).FirstOrDefault();
            Comment com = new Comment();
                com.ID = Convert.ToInt32(comment.ID);
            com.Rating = comment.Rating;
            com.UserId = comment.UserId;
            com.BlogId = comment.BlogId;
            com.Comment1 = comment.Comment1;
            return PartialView(com);
        }

        [HttpPost]
        public ActionResult UpdateComment(Comment comment)
        {

            Comment commentdb = dBBlogReviewEntities.Comments.Where(x => x.ID == comment.ID).FirstOrDefault();
            Comment com = new Comment();
            commentdb.ID = Convert.ToInt32(comment.ID);
            commentdb.Rating = comment.Rating;
            commentdb.UserId = comment.UserId;
            commentdb.BlogId = comment.BlogId;
            commentdb.Comment1 = comment.Comment1;
            dBBlogReviewEntities.SaveChanges();
            return View();
        }

        //Approve Comment
        public ActionResult ApproveComment(int id)
        {
            foreach (var x in dBBlogReviewEntities.Comments.Where((y => y.ID == id)))
            {
                x.Status = "Approved";
            }
            dBBlogReviewEntities.SaveChanges();
            return null;
        }

        //Discard Comment
        public ActionResult DiscardComment(int id )
        {
            var list = dBBlogReviewEntities.Comments.Single((y => y.ID == id)); ;
            dBBlogReviewEntities.Comments.Remove(list);
            dBBlogReviewEntities.SaveChanges();
           
            return View();
        }
    }
}
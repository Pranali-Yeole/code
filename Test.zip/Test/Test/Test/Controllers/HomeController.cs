﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Test.Models;

namespace Test.Controllers
{
    [Authorize(Roles = "Admin, User")]
    public class HomeController : Controller
    {
        DBBlogreviewEntities dBBlogReviewEntities = new DBBlogreviewEntities();
        // GET: Home
        public ActionResult Index()
        {
            return View(dBBlogReviewEntities.Blogs.ToList());
        }

        public ActionResult Details(int id)
        {   
            float sum = 0;
            float cnt = 0;
            foreach(var item in dBBlogReviewEntities.Comments)
            {
                if(item.BlogId == id)
                {
                    sum += item.Rating;
                    cnt++;
                }
            }
            float avg = (sum / cnt);
            ViewBag.avgRating = avg;
            var selectedBlog = dBBlogReviewEntities.Blogs.Single(blog => blog.ID == id);
            return View(selectedBlog);
        }

        [HttpPost]
        public ActionResult AddComment(Comment comment , int Blogid)
        {
            Comment c = new Comment();
            c.Comment1 = comment.Comment1;
            c.Rating = comment.Rating;
            c.BlogId = Blogid;
            c.UserId = comment.UserId;
            c.Status = "Pending";
            dBBlogReviewEntities.Comments.Add(c);
            dBBlogReviewEntities.SaveChanges();
            return RedirectToAction("Index");
        }

       

        public ActionResult ShowComment(int id)
        {
            var list = dBBlogReviewEntities.Comments.Where((y => y.BlogId == id)).Where((x => x.Status == "Approved")).ToList();
            return View(list);
        }
    }

}